package com.group.dto;

public class ApplicationForm {

}
